My Jarvis — Full Android Project (Iron-Man Blue, Hotword 'Jarvis', Whisper flow)
==============================================================================

What's included (placeholder / starter project):
- Iron-Man Blue themed UI (activity_main.xml)
- MainActivity in Kotlin with a "press to listen" flow and OpenAI Whisper + Chat API examples
- Instructions to add Porcupine (Picovoice) for true hotword listening
- GitHub Actions workflow to build debug APK automatically
- How to set OPENAI_API_KEY in GitHub Actions or local.properties

IMPORTANT:
- This is a starter project. For production-level always-listening hotword detection, integrate Picovoice/Porcupine native SDK.
- Whisper on-device is heavy. The project uses an API upload pattern (record audio -> send to OpenAI /v1/audio/transcriptions).
- Replace placeholders with your OpenAI API key before building.

Build with GitHub Actions:
1. Add repository secrets (Settings -> Secrets):
   - OPENAI_API_KEY : sk-...
2. Commit and push. Go to Actions -> Build Android APK -> Run workflow.
3. Download artifact app-debug.apk from workflow run.

Local build:
- Open in Android Studio (recommended on PC)
- Add local.properties with OPENAI_API_KEY=sk-...
- Build APK

