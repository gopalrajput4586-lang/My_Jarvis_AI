Hotword (Wake word) integration guide
------------------------------------
For always-listening hotword "Jarvis" integrate Porcupine (Picovoice) SDK:

1. Sign up at picovoice.ai and create a custom wake word (Jarvis) or use built-in models.
2. Add native libraries for Android (armeabi-v7a/arm64-v8a) and the jar binding.
3. Add code to start Porcupine in a foreground service and listen continuously.
4. On detection, trigger the speech recording + Whisper transcription flow.

Note: Porcupine is paid for custom wakewords but they provide trial and docs.
