package com.example.myjarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.myjarvis.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private var tts: TextToSpeech? = null
    private val http = OkHttpClient()
    private val OPENAI_KEY = BuildConfig.OPENAI_API_KEY
    private val HOTWORD = "Jarvis"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        tts = TextToSpeech(this, this)
        binding.tvStatus.text = "Ready — say 'Jarvis' or press Listen"
        binding.btnListen.setOnClickListener { ensurePermissionThenListen() }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("en", "IN")
        }
    }

    private fun ensurePermissionThenListen() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        } else {
            startSpeechRecognizer()
        }
    }

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val matches = result.data!!.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!matches.isNullOrEmpty()) {
                val heard = matches[0]
                binding.tvTranscript.append("\nYou: $heard")
                val cleaned = if (heard.trim().lowercase().startsWith(HOTWORD.lowercase())) {
                    heard.trim().substringAfter(" ", "")
                } else heard
                processCommand(cleaned)
            }
        }
    }

    private fun startSpeechRecognizer() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        speechLauncher.launch(i)
    }

    private fun processCommand(text: String) {
        binding.tvStatus.text = "Processing..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val json = JSONObject()
                json.put("model", "gpt-4o-mini")
                val messages = org.json.JSONArray()
                val mSystem = JSONObject()
                mSystem.put("role", "system")
                mSystem.put("content", "You are Jarvis assistant. Understand Hindi and English.")
                messages.put(mSystem)
                val mUser = JSONObject()
                mUser.put("role", "user")
                mUser.put("content", text)
                messages.put(mUser)
                json.put("messages", messages)

                val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                val req = Request.Builder()
                    .url("https://api.openai.com/v1/chat/completions")
                    .header("Authorization", "Bearer $OPENAI_KEY")
                    .post(body)
                    .build()

                val res = http.newCall(req).execute()
                val respBody = res.body?.string()
                val content = JSONObject(respBody).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                runOnUiThread {
                    binding.tvTranscript.append("\nJarvis: $content")
                    speak(content)
                    binding.tvStatus.text = "Ready"
                }
            } catch (e: Exception) {
                runOnUiThread { binding.tvStatus.text = "Error: ${e.message}" }
            }
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utter")
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.shutdown()
    }
}
